package main.kotlin.ducksim

import ducksim.State

class FlyNoWay : FlyBehavior {
    override val state = State.SWIMMING
}