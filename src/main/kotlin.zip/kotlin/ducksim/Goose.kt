package main.kotlin.ducksim

class Goose {
    val honkText = "Honk"
    val name = "Goose"
}